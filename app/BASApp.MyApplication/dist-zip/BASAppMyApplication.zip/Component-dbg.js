sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("BASApp.MyApplication.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);